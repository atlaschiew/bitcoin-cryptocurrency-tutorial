<?php

@header("Location: bitcoin_start_intro.php");
die;